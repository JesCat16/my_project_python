from menupedidos import menupedidos, preco, codigoproduto
def inserirproduto():
  # Confere se o arqivo existe usando o cpf colocado pelo usuário.
   cpf=input("Confirme seu CPF:")
   s=input("Confirme sua senha:")
   confirmação=[]
   pedido=[]
   codigos=[]
   valores=[]
   #A lista confirmação vai ser usada para confirmar a senha...
   lista = open("{}.txt".format(cpf),"r")
   for linhas in lista.readlines():
        linhasseparadas = linhas.strip()
        confirmação.append(linhasseparadas)
   lista.close()
   # Ela sempre estará no item 3 e se ela for igual a colocada pelo usuario se inicia a adição de novos itens...
   if confirmação[3] == s:
        print("ok")
        menupedidos()
        #Este é o arquivo que guarda os pedidos. Este arquivo formará o extrato.
        usuario = open("{}.txt".format(cpf),"a")
        #Este arquivo guarda os códigos dos produtos pedidos, ele é usado para conferencia no cancelamento de produtos.
        codigo = open("{}code.txt".format(cpf),"a")
        #Este guarda os valores da conta, ele é usado para salvar os valores acrescidos e retirados para a soma no valor total.
        valor = open("{}preco.txt".format(cpf),"a")
        #Esta área coloca os produtos, códigos e preços nas pastas. O cod salva o código do produto e o q a quantidade dele.
        print("Coloque o código de seu pedido, quando terminar coloque 0 para voltar para o menu principal.")
        cod = str(input("Coloque o código do produto que você quer: "))
        q = int(input("Quantidade deste produto: "))
         #A pasta codigos salva os códigos para o arquivo {}code.txt.
        codigos.append("%s" % cod)
        #A pasta valores salva os valores já multiplicados pela quantidade para o aquivo {}preco.txt.
        valores.append("%.2f" % float(preco(cod)*q))
        #A pasta pedidos salva os pedidos já no formato para o extrato no arquivo {}.txt
        pedido.append("%d - %s - Preço Unitário: %.2f Valor: +%.2f\n"%(q,codigoproduto(cod),float(preco(cod)),float(preco(cod))*q))
        #Enquanto o usuário não colocar 0 nas duas tags o while vai adicionar mais itens as listas.
        while True:
          cod = str(input("Coloque o código do produto: "))
          q = int(input("Quantidade deste produto: "))
          if cod !="0": 
           codigos.append("%s" % cod)
           valores.append("%.2f" % float(preco(cod)*q))
           pedido.append("%d - %s - Preço Unitário: %.2f Valor: +%.2f\n"%(q,codigoproduto(cod),float(preco(cod)),float(preco(cod)*q)))
          else:
            break
        # Para adicionar os itens da pasta pedidos ao arquivo {}.txt
        for items in pedido:
          usuario.write("%s " % items)
        usuario.close()
        # Para adicionar os itens da pasta codigos ao arquivo {}code.txt
        for itens in codigos:
          codigo.write("%s " % itens)
        codigo.close()
        # Para adicionar os itens da pasta valores ao arquivo {}preco.txt
        for precos in valores:
          valor.write('%s ' % precos)
        valor.close()
   #Caso a senha seja incorreta o usuário é levado ao menu principal
   else:
     print('senha incorreta')
