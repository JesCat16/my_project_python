from novopedido import novopedido
from cancelarpedido import cancelarpedido
from inserirproduto import inserirproduto
from cancelarproduto import cancelarproduto
from valortotal import valordopedido
from extrato import extratodopedido

def menuprincipal():
  while True:
   #Pede ao usuário para colocar o número da operação que ele quer realizar.
   print("Menu Opções:\n1 - Novo Pedido\n2 - Cancela Pedido\n3 - Insere produto\n4 - Cancela produto\n5 - Valor do pedido\n6 - Extrato do pedido\n\n0 - Sair")
   entrar=int(input("Digite opção que gostaria de realizar: "))
   #Entra no módulo da operação desejada.
   if entrar == 1:
     novopedido()
   elif entrar == 2:
     cancelarpedido()
   elif entrar == 3:
     inserirproduto()
   elif entrar == 4:
     cancelarproduto()
   elif entrar == 5:
     valordopedido()
   elif entrar == 6:
     extratodopedido()
   #Sai do while e termina o código.
   elif entrar == 0:
     break
#Permite que, apenas caso o mainmenu for o código main ele seja rodado. 
if __name__ =="__main__":
  menuprincipal()