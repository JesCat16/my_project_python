import datetime
def extratodopedido():
  #Confere se o arqivo existe usando o cpf colocado pelo usuário.
  cpf=input("Confirme seu CPF:")
  s=input("Confirme sua senha:")
  confirmação=[]
  #A tag now busca a data e hora atual.
  now = datetime.datetime.now()
  #A lista confirmação vai ser usada para confirmar a senha...
  lista = open("{}.txt".format(cpf),"r")
  for linhas in lista.readlines():
     linhasseparadas = linhas.strip()
     confirmação.append(linhasseparadas)
  lista.close()
  #Ela sempre estará no item 3 e se ela for igual a colocada pelo usuario ele permitirá que o usuário veja o extrato...
  if confirmação[3] == s:
        #Print com o nome.
        print(confirmação[0])
        #Print com o cpf.
        print(confirmação[1])
        #Código com a fórmula com o calculo do valor total 
        valor = open("{}preco.txt".format(cpf),"r")
        p = valor.readlines()
        valor.close()
        for i in p:
            inovo = i.split()
        Valortotal = 0
        for elementos in inovo:
            Valortotal = float(elementos) + Valortotal
        #Print com o valor total
        print("Total: R$",Valortotal)
        #Print da data e da hora.
        print(now.strftime("Date: %Y-%m-%d %H:%M"))
        #Print dos pedidos em ordem.
        print("Itens do pedido:")
        for l in confirmação[5:]:
            print(l)
  #Caso a senha seja incorreta o usuário é levado ao menu principal
  else:
      print("Senha Incorreta")