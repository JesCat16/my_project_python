import os
from menupedidos import menupedidos, preco, codigoproduto
def novopedido():
  #Cadastramento da conta:
  inf={"Nome":0, "CPF":0,"Senha":0}
  Nome = input("Nome: ")
  CPF = input("CPF: ")
  Senha = input("Senha: ")
  pedido=[]
  codigos=[]
  valores = []
  inf["Nome"] = Nome
  inf["CPF"] = CPF
  inf["Senha"] = Senha
  pasta = "{}.txt".format(CPF)
  #Este confere se a conta já existe, se ela existir ele diz que já existe e volta para o menu principal
  if os.path.exists(pasta):
    print("Sua conta já existe!")
  #Caso não ele continua o cadastro abrindo 3 arquivos...
  else:
    #Este é o arquivo que guarda as informações como: Nome, CPF, Senha e os pedidos. Este arquivo formará o extrato.
    with open("{}.txt".format(CPF),"w") as usuario:
      for key,value in inf.items():
        usuario.write("%s: %s\n" % (key,value))
      #Esta segunada senha é usada para a conferencia de senhas nos outros módulos.
      usuario.write(Senha)
      usuario.write(" \n")
      usuario.write("Pedido:\n")
      menupedidos()
      #Este arquivo guarda os códigos dos produtos pedidos, ele é usado para conferencia no cancelamento de produtos.
      codigo = open("{}code.txt".format(CPF),"w")
      #Este guarda os valores da conta, ele é usado para salvar os valores acrescidos e retirados para a soma no valor total.
      valor = open("{}preco.txt".format(CPF),"w")
      #Esta área coloca os produtos, códigos e preços nas pastas. O cod salva o código do produto e o q a quantidade dele.
      print("Coloque o código de seu pedido, quando terminar coloque 0 para voltar para o menu principal.")
      cod = str(input("Coloque o código do produto que você quer: "))
      q = int(input("Quantidade deste produto: "))
      #A pasta codigos salva os códigos para o arquivo {}code.txt.
      codigos.append("%s" % cod)
      #A pasta valores salva os valores já multiplicados pela quantidade para o aquivo {}preco.txt.
      valores.append("%.2f" % float(preco(cod)*q))
      #A pasta pedidos salva os pedidos já no formato para o extrato no arquivo {}.txt
      pedido.append("%d - %s - Preço Unitário: %.2f Valor: +%.2f\n"%(q,codigoproduto(cod),float(preco(cod)),float(preco(cod))*q))
      #Enquanto o usuario não colocar 0 nas duas tags o while vai adicionar mais itens as listas. 
      while True:
       cod = str(input("Coloque o código do produto: "))
       q = int(input("Quantidade deste produto: "))
       if cod !="0": 
        codigos.append("%s" % cod)
        valores.append("%.2f" % float(preco(cod)*q))
        pedido.append("%d - %s - Preço Unitário: %.2f Valor: +%.2f\n"%(q,codigoproduto(cod),float(preco(cod)),float(preco(cod))*q))
       else:
         break
      # Para adicionar os itens da pasta pedidos ao arquivo {}.txt
      for items in pedido:
       usuario.write("%s " % items)
      usuario.close()
      # Para adicionar os itens da pasta codigos ao arquivo {}code.txt
      for itens in codigos:
        codigo.write("%s " % itens)
      codigo.close()
      # Para adicionar os itens da pasta valores ao arquivo {}preco.txt
      for precos in valores:
        valor.write('%s ' % precos)
      valor.close()

    

