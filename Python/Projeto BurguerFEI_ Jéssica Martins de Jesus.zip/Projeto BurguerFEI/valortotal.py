def valordopedido():
    #Confere se o arqivo existe usando o cpf colocado pelo usuário.
    cpf=input("Confirme seu CPF:")
    s=input("Confirme sua senha:")
    confirmação=[]
    #A lista confirmação vai ser usada para confirmar a senha...
    lista = open("{}.txt".format(cpf),"r")
    for linhas in lista.readlines():
            linhasseparadas = linhas.strip()
            confirmação.append(linhasseparadas)
    lista.close()
    #Ela sempre estará no item 3 e se ela for igual a colocada pelo usuario ele permitirá que o usuário veja o valor do pedido...
    if confirmação[3] == s:
        #Os valores serão retirado o arquivo {}preco.txt e guardados no inovo.
        valor = open("{}preco.txt".format(cpf),"r")
        p = valor.readlines()
        valor.close()
        for i in p:
            inovo = i.split()
        Valortotal = 0
        #Este for pegará o valor da lista e somar aos já somados, no início o valor é igual a 0 e irá acumulando os valores. 
        for elementos in inovo:
            Valortotal = float(elementos) + Valortotal
        #Por fim o valor será mostrado ao usuário. 
        print("R$",Valortotal)
    #Caso a senha seja incorreta o usuário é levado ao menu principal
    else:
        print("Senha Incorreta")