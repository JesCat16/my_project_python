import os 
def cancelarpedido():
    # Confere se o arqivo existe usando o cpf colocado pelo usuário.
    cpf=input("Confirme seu CPF:")
    s=input("Confirme sua senha:")
    confirmação=[]
    #A lista confirmação vai ser usada para confirmar a senha...
    lista = open("{}.txt".format(cpf),"r")
    for linhas in lista.readlines():
       linhasseparadas = linhas.strip()
       confirmação.append(linhasseparadas)
    lista.close()
    # Ela sempre estará no item 3 e se ela for igual a colocada pelo usuario ele permitirá o cancelamento do pedido...
    if confirmação[3] == s:
        #O código perguntará se o usuário tem certeza se ele quer cancelar...
        print("Tem certeza que gostaria de cancelar o pedido?")
        conf=input("Sim/Não?")
        #Se sim...
        if conf == "Sim":
            #Os 3 arquivos criados serão apagados.
            os.remove("{}.txt".format(cpf))
            os.remove("{}code.txt".format(cpf))
            os.remove("{}preco.txt".format(cpf))
        #Se não...
        else:
            #O usuário voltará ao menu principal.
            print("OK! Então vamos continuar")
    #Caso a senha seja incorreta o usuário é levado ao menu principal
    else:
       print('senha incorreta')
