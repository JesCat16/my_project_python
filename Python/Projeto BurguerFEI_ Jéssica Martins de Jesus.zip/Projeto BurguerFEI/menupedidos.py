#função que dá print do cardápio completo.
def menupedidos():
    inicio = ["Código"," Produto","         Preço"]
    it1=[1,"      X-salada","        R$ 10,00"]
    it2=[2,"      X-burguer","       R$ 10,00"]
    it3=[3,"      Cachorro quente", " R$ 7,50"]
    it4=[4,"      Misto quente","    R$ 8,00"]
    it5=[5,"      Salada de frutas","R$ 5,50"]
    it6=[6,"      Refrigerante","    R$ 4,50"]
    it7=[7,"      Suco natural","    R$ 6,25"]
    print(*inicio)
    print(*it1)
    print(*it2)
    print(*it3)
    print(*it4)
    print(*it5)
    print(*it6)
    print(*it7)
#Fução que salva a relação código-produto.
def codigoproduto(cod):
    codigmenu={
        "1":"X-salada",
       "2":"X-burguer",
        "3":"Cachorro_quente",
        '4':"Misto_quente",
        '5':"Salada_de_frutas",
        "6":"Refrigerante",
        '7':"Suco_natural"
    }
    print(codigmenu[cod])
    return codigmenu[cod]
#Função que salva a relação código-preço
def preco(cod):
    codigpreco={
       "1":10,
       "2":10,
       "3" :7.5,
       "4" :8,
        "5" :5.5,
        "6" :4.5,
        "7" :6.25
    }
    return codigpreco[cod]
