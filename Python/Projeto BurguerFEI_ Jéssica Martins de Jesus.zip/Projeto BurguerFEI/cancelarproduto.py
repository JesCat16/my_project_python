from menupedidos import menupedidos, codigoproduto, preco
def cancelarproduto():
     # Confere se o arqivo existe usando o cpf colocado pelo usuário.
    cpf=input("Confirme seu CPF:")
    s=input("Confirme sua senha:")
    confirmação=[]
    pedido=[]
    valor = []
    #A lista confirmação vai ser usada para confirmar a senha...
    lista = open("{}.txt".format(cpf),"r")
    #Este arquivo é usado para a leitura dos códigos dos produtoa que o usuário pediu.
    codigo = open("{}code.txt".format(cpf),"r")
    for linhas in lista.readlines():
            linhasseparadas = linhas.strip()
            confirmação.append(linhasseparadas)
    lista.close()
    # Ela sempre estará no item 3 e se ela for igual a colocada pelo usuario ele permitirá a retirada de um item...
    if confirmação[3] == s:
        menupedidos()
        # O cod é usado para o usuário colocar qual item ele quer retirar.
        cod=input("Qual o código do produto que deseja cancelar: ")
        #Este código retira os codigos do produto e coloca na pasta inovo.
        p = codigo.readlines()
        for i in p:
            inovo=i.split()
        codigo.close()
        #No arquivo {}.txt coloca-se o item cancelado já no formato do extrato 
        pedidos = open("{}.txt".format(cpf),"a")
        #No arquivo {}preco.txt coloca-se o item cancelado com o preço negativo para o valor total 
        valores = open("{}preco.txt".format(cpf),"a")
        #Este for busca pelo item que o usuário quer cancelar...
        for i in inovo:
            # Se ele for encontrado...
            if i == cod:
                #Pergunta-se ao usuário quanto do item ele quer cancelar.
                q=int(input("Quantos você quer deletar: "))
                #Salva o cancelamento na pasta pedido.
                pedido.append("%d - %s - Preço Unitário: %.2f Valor: -%.2f - Cancelado\n"%(q,codigoproduto(cod),float(preco(cod)),float(preco(cod))*q))
                #Salva o valor negativo do cancelamento.
                valor.append("%.2f" % float(preco(cod)*(q*-1)))
                # Para adicionar o cancelamento do item da pasta pedidos ao arquivo {}.txt
                for items in pedido:
                 pedidos.write("%s " % items)
                pedidos.close()
                # Para adicionar o item negativo da pasta valores ao arquivo {}preco.txt
                for precos in valor:
                 valores.write('%s ' % precos)
                valores.close()
                break
            # Se ele não encontrar...
            else:
                #Ele continuará procurando por toda a lista, mas se não encontrar ele voltará ao menu principal 
                print("Item não encontrado")
    #Caso a senha seja incorreta o usuário é levado ao menu principal
    else:
        print("Senha Incorreta")